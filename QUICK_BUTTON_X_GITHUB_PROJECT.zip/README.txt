QUICK BUTTON X v1.3

- Screenshot Quick Settings tile launches a transparent permission helper, not the QUICK BUTTON X dashboard.
- After Android consent, helper closes and capture service waits 1.8 seconds so the app underneath should be visible; screenshot saves to Pictures/Screenshots.
- Android screen-capture consent is mandatory and cannot be forced or bypassed.
- Dashboard screenshot button explains how to use the Quick Settings tile; use the tile to capture another app, not the dashboard.
- Livin' picker lets user select an installed launcher app; package visibility is enabled with QUERY_ALL_PACKAGES.
- Select Livin' in QUICK BUTTON X > PILIH / GANTI APLIKASI LIVIN'. If no Livin'-label match appears, the picker falls back to all launchable installed apps.
- Livin' Quick Settings tile opens the saved app selection.
- Screenshot history remains available in the app.

Upload this ZIP to GitHub root with filename QUICK_BUTTON_X_GITHUB_PROJECT.zip.
Add .github/workflows/build.yml from the separate build.yml, run Actions, download QUICK-BUTTON-X-APK-v1.3.
Source is prepared but has not been built/tested on the physical Narzo 50i.
