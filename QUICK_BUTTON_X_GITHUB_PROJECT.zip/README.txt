QUICK BUTTON X v1.1

Home app:
- VOLUME: opens Android volume panel.
- SCREENSHOT: requests Android screen-capture consent, then saves screenshot to Pictures/Screenshots.
- LIVIN': launches the installed Livin' by Mandiri app if its package ID matches.
- Screenshot history: shows saved screenshots; tap an item to open it.

Quick Settings:
Add VOLUME, SCREENSHOT, and LIVIN' tiles from Android Quick Settings edit/pencil screen.

Build with one ZIP upload:
1. Upload QUICK_BUTTON_X_GITHUB_PROJECT.zip to repository root.
2. Add .github/workflows/build.yml using the separate build.yml file.
3. Open Actions and run Build QUICK BUTTON X.
4. Download artifact QUICK-BUTTON-X-APK-v1.1.

Important:
- Android screen-capture consent cannot be auto-forced or silently remembered. Android may ask again for each new capture.
- Foreground service uses mediaProjection type and a low-importance, silent notification while capture is active. Android controls whether it is displayed.
- This source is prepared but APK build/device testing is still required.
- If Livin' does not launch, the package name used by the installed Livin' release may differ and must be adjusted.
