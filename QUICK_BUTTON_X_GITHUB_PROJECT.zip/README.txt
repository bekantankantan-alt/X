QUICK BUTTON X v1.4

Fitur Quick Settings:
- SCREENSHOT: minta izin resmi Android, lalu kembali ke layar/aplikasi yang sedang terbuka dan mengambil screenshot layar tersebut setelah jeda singkat.
- VOLUME: membuka kontrol volume.
- LIVIN': membuka aplikasi pilihan.
- GALERI: membuka aplikasi galeri bawaan jika tersedia; jika tidak, membuka pemilih gambar Android.
- KAMERA: membuka aplikasi kamera bawaan melalui intent kamera Android.

Cara memakai screenshot:
1. Buka aplikasi/halaman yang ingin di-screenshot.
2. Tarik panel notifikasi/Quick Settings.
3. Tekan tile SCREENSHOT.
4. Jika Android meminta izin rekam layar, pilih mulai/izinkan.
5. Tunggu sekitar 2,5 detik. Screenshot disimpan di Pictures/Screenshots.

Catatan:
- Android mewajibkan persetujuan perekaman layar. Aplikasi tidak dapat melewati atau menghilangkan dialog izin.
- Saat dialog izin muncul, setelah disetujui Android akan kembali ke layar sebelumnya. Jangan membuka aplikasi lain selama jeda screenshot.
- Nama/letak tile tergantung tampilan Quick Settings ponsel. Tambahkan tile GALERI dan KAMERA dari tombol Edit/Pensil pada panel Quick Settings.
- GALERI memakai aplikasi galeri bawaan jika Android/ponsel menyediakan kategori aplikasi galeri; jika tidak, sistem menampilkan pemilih gambar.
- KAMERA membuka aplikasi kamera bawaan yang terdaftar sebagai penangan intent kamera.
- Source disiapkan untuk dibuild melalui GitHub Actions; tetap perlu diuji di Realme Narzo 50i.

Upload ZIP ini ke root repository GitHub dengan nama QUICK_BUTTON_X_GITHUB_PROJECT.zip.
Simpan workflow sebagai .github/workflows/build.yml, jalankan Actions, lalu unduh artifact QUICK-BUTTON-X-APK-v1.4.
