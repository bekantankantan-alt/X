QUICK BUTTON X v1.2

FIXES:
- Screenshot flow now closes the dashboard after Android consent and before capture, returning to the app that was underneath. The screenshot should no longer show Quick Button X itself.
- Livin' picker is added. Tap PILIH / GANTI APLIKASI LIVIN' and select the installed Livin' app. The selection is saved and used by the home button.
- If Android cannot identify the Livin' package by name, the picker shows installed launchable apps so the user can select it manually.
- Screenshot history remains in the app and opens saved images.

BUILD:
1. Upload this ZIP to the GitHub repository root using the exact filename QUICK_BUTTON_X_GITHUB_PROJECT.zip.
2. Add .github/workflows/build.yml using build.yml provided separately.
3. Run Actions > Build QUICK BUTTON X.
4. Download artifact QUICK-BUTTON-X-APK-v1.1 (artifact label retained by workflow).

NOTE:
Android requires explicit screen-capture consent. It cannot be silently bypassed. Foreground service notification is low-importance and silent while capture runs.
