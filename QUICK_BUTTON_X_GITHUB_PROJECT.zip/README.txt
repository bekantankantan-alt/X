QUICK BUTTON X - Android project

Target: Android 11 / Realme Narzo 50i.
Tiles: VOLUME, SCREENSHOT, LIVIN'.

BUILD:
1. Upload/extract this project into a GitHub repository (project files must be at repository root).
2. Put build.yml at .github/workflows/build.yml (the workflow file is also included in this ZIP).
3. Open GitHub > Actions > Build QUICK BUTTON X > Run workflow.
4. Download the APK from the workflow artifact.

IMPORTANT:
- GitHub does not unpack a ZIP uploaded as a repository file. The ZIP must be extracted before its contents become the repository source. If using only a phone, use GitHub's web editor or an archive-capable Git client to extract/upload.
- Android requires the user to approve screen capture. This first implementation may request permission again on a later screenshot because Android controls MediaProjection session lifetime; it cannot force-grant this permission.
- Screenshot is saved under Pictures/Screenshots.
- Livin' package IDs vary by app version/device. The tile tries common package IDs; if it does not open, package ID needs adjusting.
- To show the tiles: swipe down twice > Edit/Pencil > find VOLUME, SCREENSHOT, LIVIN' > drag into active tiles.
