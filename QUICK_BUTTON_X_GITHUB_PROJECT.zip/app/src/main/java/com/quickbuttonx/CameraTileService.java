package com.quickbuttonx;

import android.content.Intent;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class CameraTileService extends TileService {
    @Override public void onClick() {
        Intent camera = new Intent("android.media.action.IMAGE_CAPTURE");
        try {
            startActivityAndCollapse(camera);
        } catch (Exception e) {
            Toast.makeText(this, "Aplikasi kamera tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
    }
}
