package com.quickbuttonx;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.service.quicksettings.TileService;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class CameraTileService extends TileService {
    @Override public void onClick() {
        try {
            // Find and launch the installed native Camera/Kamera app.
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = getPackageManager().queryIntentActivities(launcher, 0);
            if (apps != null) {
                for (ResolveInfo app : apps) {
                    String label = String.valueOf(app.loadLabel(getPackageManager())).toLowerCase(Locale.ROOT);
                    String pkg = app.activityInfo.packageName.toLowerCase(Locale.ROOT);
                    if ((label.contains("camera") || label.contains("kamera") || pkg.contains("camera")) && !label.contains("google lens")) {
                        Intent launch = getPackageManager().getLaunchIntentForPackage(app.activityInfo.packageName);
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivityAndCollapse(launch);
                            return;
                        }
                    }
                }
            }
            Intent camera = new Intent("android.media.action.IMAGE_CAPTURE");
            camera.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (camera.resolveActivity(getPackageManager()) != null) startActivityAndCollapse(camera);
            else Toast.makeText(this, "Aplikasi kamera tidak ditemukan.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Kamera tidak bisa dibuka. Pastikan aplikasi Kamera tersedia.", Toast.LENGTH_LONG).show();
        }
    }
}
