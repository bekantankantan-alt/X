package com.quickbuttonx;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.widget.Toast;
import java.nio.ByteBuffer;

public class ScreenshotCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "quick_button_capture";
    private static final int NOTIFICATION_ID = 42;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean stopping = false;
    private int retryCount = 0;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(startId); return START_NOT_STICKY; }
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setContentTitle("QUICK BUTTON X")
            .setContentText("Screenshot sedang diproses…")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData;
            if (Build.VERSION.SDK_INT >= 33) resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            else resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (resultCode != android.app.Activity.RESULT_OK || resultData == null) throw new IllegalStateException("Izin screenshot tidak valid");

            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("MediaProjection tidak tersedia");
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Gagal memulai MediaProjection");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!stopping) cleanup();
                }
            }, handler);

            WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            int density = metrics.densityDpi;
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
            display = projection.createVirtualDisplay("QuickButtonX-Screenshot", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
            if (display == null) throw new IllegalStateException("Virtual display gagal dibuat");
            // Allow the screen underneath the permission dialog/activity to become visible and render.
            handler.postDelayed(this::saveScreenshot, 1200);
        } catch (Exception e) {
            showError("Screenshot gagal dimulai: " + e.getMessage());
            cleanup();
        }
        return START_NOT_STICKY;
    }

    private void saveScreenshot() {
        if (stopping || reader == null) return;
        Image image = null;
        Bitmap full = null;
        Bitmap cropped = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                if (retryCount++ < 5) { handler.postDelayed(this::saveScreenshot, 350); return; }
                throw new IllegalStateException("Layar belum siap diambil");
            }
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int width = reader.getWidth();
            int height = reader.getHeight();
            int rowPadding = rowStride - pixelStride * width;
            int paddedWidth = width + rowPadding / pixelStride;
            full = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind();
            full.copyPixelsFromBuffer(buffer);
            cropped = Bitmap.createBitmap(full, 0, 0, width, height);

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "Screenshot_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots");
            android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Tidak bisa membuat file screenshot");
            try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("Tidak bisa menyimpan file");
                cropped.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
            }
            Toast.makeText(this, "Screenshot tersimpan di Pictures/Screenshots", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            showError("Gagal menyimpan screenshot: " + e.getMessage());
        } finally {
            if (image != null) image.close();
            if (cropped != null && !cropped.isRecycled()) cropped.recycle();
            if (full != null && !full.isRecycled()) full.recycle();
            cleanup();
        }
    }

    private void showError(String message) {
        handler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Screenshot", NotificationManager.IMPORTANCE_LOW);
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.setDescription("Proses pengambilan screenshot");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private void cleanup() {
        if (stopping) return;
        stopping = true;
        handler.removeCallbacksAndMessages(null);
        try { if (display != null) display.release(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        MediaProjection oldProjection = projection;
        display = null; reader = null; projection = null;
        try { if (oldProjection != null) oldProjection.stop(); } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
