package com.quickbuttonx;

import android.content.Intent;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class ScreenshotTileService extends TileService {
    @Override public void onClick() {
        try {
            Intent i = new Intent(this, CapturePermissionActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivityAndCollapse(i);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa memulai screenshot. Buka QUICK BUTTON X lalu coba lagi.", Toast.LENGTH_LONG).show();
        }
    }
}
