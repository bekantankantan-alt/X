package com.quickbuttonx;
import android.content.Intent;
import android.service.quicksettings.TileService;
public class ScreenshotTileService extends TileService {
 @Override public void onClick() {
   Intent i = new Intent(this, MainActivity.class);
   i.setAction(MainActivity.ACTION_TILE_SCREENSHOT);
   i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
   startActivityAndCollapse(i);
 }
}
