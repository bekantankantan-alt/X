package com.quickbuttonx;

import android.content.Intent;
import android.service.quicksettings.TileService;

public class ScreenshotTileService extends TileService {
    @Override public void onClick() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setAction(MainActivity.ACTION_TAKE_SCREENSHOT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityAndCollapse(intent);
    }
}
