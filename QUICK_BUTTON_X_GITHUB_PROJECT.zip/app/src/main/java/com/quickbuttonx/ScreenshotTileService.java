package com.quickbuttonx;
import android.content.Intent;
import android.service.quicksettings.TileService;
public class ScreenshotTileService extends TileService {
    @Override public void onClick() {
        Intent i = new Intent(this, CapturePermissionActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityAndCollapse(i);
    }
}
