package com.quickbuttonx;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.database.Cursor;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 701;
    public static final String ACTION_TILE_SCREENSHOT = "com.quickbuttonx.TILE_SCREENSHOT";
    private LinearLayout historyContainer;
    private MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildScreen();
        loadHistory();
        if (ACTION_TILE_SCREENSHOT.equals(getIntent().getAction())) {
            new android.os.Handler().postDelayed(this::requestScreenshot, 250);
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(0xFFF4F7FC);
        scroll.addView(root);

        TextView title = label("QUICK BUTTON X", 25, 0xFF10233F);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);
        TextView subtitle = label("Pusat tombol cepat", 14, 0xFF61718A);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        Button volume = button("🔊   VOLUME");
        root.addView(volume, matchWrap());
        volume.setOnClickListener(v -> {
            AudioManager audio = (AudioManager)getSystemService(AUDIO_SERVICE);
            if (audio != null) audio.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
        });

        Button shot = button("📸   AMBIL SCREENSHOT");
        root.addView(shot, matchWrap());
        shot.setOnClickListener(v -> requestScreenshot());

        Button livin = button("🏦   BUKA LIVIN' BY MANDIRI");
        root.addView(livin, matchWrap());
        livin.setOnClickListener(v -> openLivin());

        TextView historyTitle = label("RIWAYAT SCREENSHOT", 18, 0xFF10233F);
        historyTitle.setTypeface(null, 1);
        historyTitle.setPadding(0, dp(24), 0, dp(8));
        root.addView(historyTitle);

        TextView historyHint = label("Screenshot yang dibuat melalui aplikasi ini akan muncul di sini.", 13, 0xFF61718A);
        root.addView(historyHint);

        historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(historyContainer);

        Button refresh = button("↻   MUAT ULANG RIWAYAT");
        root.addView(refresh, matchWrap());
        refresh.setOnClickListener(v -> loadHistory());

        setContentView(scroll);
    }


    private void requestScreenshot() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        return p;
    }

    private void openLivin() {
        String[] packages = {"com.bankmandiri.mandirionline", "id.co.bankmandiri.livin"};
        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) { startActivity(launch); return; }
        }
        Toast.makeText(this, "Livin' by Mandiri belum ditemukan. Pastikan aplikasinya sudah terpasang.", Toast.LENGTH_LONG).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenshotCaptureService.class);
                service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_DATA, data);
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
                Toast.makeText(this, "Sedang mengambil screenshot…", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Izin screenshot dibatalkan.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (historyContainer != null) loadHistory();
    }

    private void loadHistory() {
        if (historyContainer == null) return;
        historyContainer.removeAllViews();
        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED};
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
        String[] args = {"Pictures/Screenshots/"};
        try (Cursor c = getContentResolver().query(collection, projection, selection, args,
                MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            int count = 0;
            if (c != null) while (c.moveToNext()) {
                long id = c.getLong(0);
                String name = c.getString(1);
                long date = c.getLong(2);
                Uri item = Uri.withAppendedPath(collection, Long.toString(id));
                Button row = button("🖼  " + name + "\n" +
                    new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(date * 1000)));
                historyContainer.addView(row, matchWrap());
                row.setOnClickListener(v -> {
                    Intent view = new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(item, "image/*");
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(view);
                });
                count++;
            }
            if (count == 0) {
                TextView empty = label("Belum ada screenshot tersimpan.", 14, 0xFF718096);
                empty.setPadding(0, dp(12), 0, dp(8));
                historyContainer.addView(empty);
            }
        } catch (Exception e) {
            TextView err = label("Riwayat belum dapat dibaca.", 14, 0xFF718096);
            historyContainer.addView(err);
        }
    }
}
