package com.quickbuttonx;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.view.WindowManager;
import android.widget.Toast;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {
    public static final String ACTION_TAKE_SCREENSHOT = "com.quickbuttonx.TAKE_SCREENSHOT";
    private static final int REQUEST_CAPTURE = 701;
    private MediaProjectionManager projectionManager;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (ACTION_TAKE_SCREENSHOT.equals(getIntent().getAction())) {
            new Handler(Looper.getMainLooper()).postDelayed(() ->
                startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE), 250);
        } else {
            Toast.makeText(this, "Tambahkan tile VOLUME, SCREENSHOT, dan LIVIN' melalui Edit Quick Settings.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Izin screenshot tidak diberikan.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        try {
            MediaProjection projection = projectionManager.getMediaProjection(resultCode, data);
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels, height = metrics.heightPixels, density = metrics.densityDpi;
            ImageReader reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            VirtualDisplay display = projection.createVirtualDisplay("QuickButtonX",
                width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, null);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image == null) throw new Exception("Layar belum siap, coba lagi.");
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int pixelStride = plane.getPixelStride();
                    int rowStride = plane.getRowStride();
                    int rowPadding = rowStride - pixelStride * width;
                    android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(
                        width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888);
                    bitmap.copyPixelsFromBuffer(buffer);
                    android.graphics.Bitmap cropped = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, width, height);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, "Screenshot_" + System.currentTimeMillis() + ".png");
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Tidak bisa menyimpan gambar.");
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                        cropped.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
                    }
                    Toast.makeText(this, "Screenshot tersimpan di Pictures/Screenshots", Toast.LENGTH_LONG).show();
                    bitmap.recycle(); cropped.recycle();
                } catch (Exception e) {
                    Toast.makeText(this, "Screenshot gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    if (image != null) image.close();
                    display.release();
                    reader.close();
                    projection.stop();
                    finish();
                }
            }, 700);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal memulai screenshot: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }
}
