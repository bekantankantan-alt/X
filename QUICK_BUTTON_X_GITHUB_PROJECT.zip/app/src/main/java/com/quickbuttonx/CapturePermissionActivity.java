package com.quickbuttonx;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;

public class CapturePermissionActivity extends Activity {
    private static final int REQUEST_CAPTURE = 702;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null) { finish(); return; }
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        overridePendingTransition(0, 0);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, ScreenshotCaptureService.class);
            service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
