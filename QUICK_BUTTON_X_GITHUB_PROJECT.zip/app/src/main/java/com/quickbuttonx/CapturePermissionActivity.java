package com.quickbuttonx;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

public class CapturePermissionActivity extends Activity {
    private static final int REQUEST_CAPTURE = 702;
    private boolean requested;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) requested = state.getBoolean("requested", false);
        if (requested) return;
        requested = true;
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            Toast.makeText(this, "Fitur screenshot tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        try {
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal meminta izin screenshot.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putBoolean("requested", requested);
        super.onSaveInstanceState(out);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, ScreenshotCaptureService.class);
            service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_DATA, data);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            } catch (Exception e) {
                Toast.makeText(this, "Layanan screenshot gagal dijalankan.", Toast.LENGTH_LONG).show();
            }
            // Close this permission activity immediately so the capture is of the screen beneath it.
            finish();
            overridePendingTransition(0, 0);
        } else {
            Toast.makeText(this, "Izin screenshot dibatalkan.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
