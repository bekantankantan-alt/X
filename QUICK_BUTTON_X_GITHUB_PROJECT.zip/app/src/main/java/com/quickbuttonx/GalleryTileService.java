package com.quickbuttonx;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.service.quicksettings.TileService;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class GalleryTileService extends TileService {
    @Override public void onClick() {
        try {
            // Find the installed manufacturer Gallery/Photos app by its launcher name.
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = getPackageManager().queryIntentActivities(launcher, 0);
            if (apps != null) {
                for (ResolveInfo app : apps) {
                    String label = String.valueOf(app.loadLabel(getPackageManager())).toLowerCase(Locale.ROOT);
                    String pkg = app.activityInfo.packageName.toLowerCase(Locale.ROOT);
                    if (label.contains("gallery") || label.contains("galeri") || label.contains("photos") || label.contains("foto") || pkg.contains("gallery") || pkg.contains("photo")) {
                        Intent launch = getPackageManager().getLaunchIntentForPackage(app.activityInfo.packageName);
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivityAndCollapse(launch);
                            return;
                        }
                    }
                }
            }
            Intent nativeGallery = new Intent(Intent.ACTION_MAIN);
            nativeGallery.addCategory("android.intent.category.APP_GALLERY");
            if (nativeGallery.resolveActivity(getPackageManager()) != null) {
                startActivityAndCollapse(nativeGallery);
                return;
            }
            Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
            picker.setType("image/*");
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(Intent.createChooser(picker, "Buka Galeri"));
        } catch (Exception e) {
            Toast.makeText(this, "Galeri tidak bisa dibuka. Pastikan aplikasi Galeri tersedia.", Toast.LENGTH_LONG).show();
        }
    }
}
