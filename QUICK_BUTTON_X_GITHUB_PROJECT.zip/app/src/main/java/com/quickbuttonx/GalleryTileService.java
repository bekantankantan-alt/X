package com.quickbuttonx;

import android.content.Intent;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class GalleryTileService extends TileService {
    @Override public void onClick() {
        Intent gallery = new Intent(Intent.ACTION_MAIN);
        gallery.addCategory("android.intent.category.APP_GALLERY");
        if (gallery.resolveActivity(getPackageManager()) != null) {
            startActivityAndCollapse(gallery);
            return;
        }
        Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
        picker.setType("image/*");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityAndCollapse(Intent.createChooser(picker, "Buka Galeri"));
        } catch (Exception e) {
            Toast.makeText(this, "Aplikasi galeri tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
    }
}
