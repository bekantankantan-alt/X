package com.quickbuttonx;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class LivinTileService extends TileService {
    private static final String[] PACKAGES = {
        "com.bankmandiri.mandirionline",
        "id.co.bankmandiri.livin"
    };
    @Override public void onClick() {
        PackageManager pm = getPackageManager();
        for (String pkg : PACKAGES) {
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivityAndCollapse(launch);
                return;
            }
        }
        Toast.makeText(this, "Livin' by Mandiri belum ditemukan. Pastikan aplikasinya sudah terpasang.", Toast.LENGTH_LONG).show();
    }
}
