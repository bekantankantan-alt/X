package com.quickbuttonx;
import android.content.Intent;
import android.service.quicksettings.TileService;
import android.widget.Toast;
public class LivinTileService extends TileService {
    @Override public void onClick() {
        String pkg = getSharedPreferences("quick_button_prefs", MODE_PRIVATE).getString("livin_package", null);
        if (pkg == null) {
            Toast.makeText(this, "Buka QUICK BUTTON X lalu pilih aplikasi Livin' terlebih dahulu.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Toast.makeText(this, "Aplikasi pilihan tidak ditemukan. Pilih ulang dari QUICK BUTTON X.", Toast.LENGTH_LONG).show();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityAndCollapse(launch);
    }
}
