package com.quickbuttonx;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.service.quicksettings.TileService;
import android.widget.Toast;
public class LivinTileService extends TileService {
 private static final String[] PACKAGES = {"com.bankmandiri.mandirionline","id.co.bankmandiri.livin"};
 @Override public void onClick() {
   PackageManager pm = getPackageManager();
   for (String pkg : PACKAGES) {
     Intent i = pm.getLaunchIntentForPackage(pkg);
     if (i != null) { startActivityAndCollapse(i); return; }
   }
   Toast.makeText(this, "Livin' by Mandiri belum ditemukan.", Toast.LENGTH_LONG).show();
 }
}
