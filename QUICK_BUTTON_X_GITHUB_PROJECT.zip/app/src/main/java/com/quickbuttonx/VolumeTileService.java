package com.quickbuttonx;

import android.media.AudioManager;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class VolumeTileService extends TileService {
    @Override public void onClick() {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audio != null) {
            audio.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
        }
        Tile tile = getQsTile();
        if (tile != null) { tile.setState(Tile.STATE_ACTIVE); tile.updateTile(); }
    }
}
