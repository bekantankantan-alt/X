package com.quickbuttonx;
import android.media.AudioManager;
import android.service.quicksettings.TileService;
public class VolumeTileService extends TileService {
 @Override public void onClick() {
   AudioManager a = (AudioManager)getSystemService(AUDIO_SERVICE);
   if (a != null) a.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
 }
}
