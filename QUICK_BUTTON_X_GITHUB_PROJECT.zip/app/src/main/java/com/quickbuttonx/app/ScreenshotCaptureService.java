package com.quickbuttonx.app;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class ScreenshotCaptureService extends Service {
 private MediaProjection projection;
 private VirtualDisplay display;
 private ImageReader reader;
 private Handler handler=new Handler(Looper.getMainLooper());
 private static final String CHANNEL="qbx_capture";
 @Override public void onCreate() {
  super.onCreate();
  if(Build.VERSION.SDK_INT>=26) {
   NotificationChannel ch=new NotificationChannel(CHANNEL,"Screenshot QUICK BUTTON X",NotificationManager.IMPORTANCE_LOW);
   getSystemService(NotificationManager.class).createNotificationChannel(ch);
  }
  Notification n;
  if(Build.VERSION.SDK_INT>=26) n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("QUICK BUTTON X").setContentText("Mengambil screenshot…").setOngoing(true).build();
  else n=new Notification.Builder(this).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("QUICK BUTTON X").setContentText("Mengambil screenshot…").build();
  if(Build.VERSION.SDK_INT>=29) startForeground(71,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  else startForeground(71,n);
 }
 @Override public int onStartCommand(Intent in,int flags,int id) {
  if(in==null){stopSelf();return START_NOT_STICKY;}
  int code=in.getIntExtra("resultCode",0);
  Intent data;
  if(Build.VERSION.SDK_INT>=33) data=in.getParcelableExtra("resultData",Intent.class);
  else data=in.getParcelableExtra("resultData");
  if(data==null || code!=Activity.RESULT_OK){stopSelf();return START_NOT_STICKY;}
  MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  projection=mgr.getMediaProjection(code,data);
  DisplayMetrics dm=new DisplayMetrics();
  ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
  reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2);
  display=projection.createVirtualDisplay("QBX_SCREENSHOT",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
  handler.postDelayed(this::capture,1500);
  return START_NOT_STICKY;
 }
 private void capture() {
  Image img=null; Bitmap padded=null;
  try {
   img=reader.acquireLatestImage();
   if(img==null){handler.postDelayed(this::capture,400);return;}
   Image.Plane p=img.getPlanes()[0]; ByteBuffer buf=p.getBuffer();
   int px=p.getPixelStride(), row=p.getRowStride();
   padded=Bitmap.createBitmap(img.getWidth()+(row-px*img.getWidth())/px,img.getHeight(),Bitmap.Config.ARGB_8888);
   padded.copyPixelsFromBuffer(buf);
   Bitmap clean=Bitmap.createBitmap(padded,0,0,img.getWidth(),img.getHeight());
   ContentValues v=new ContentValues();
   v.put(MediaStore.Images.Media.DISPLAY_NAME,"QUICK_BUTTON_X_"+System.currentTimeMillis()+".png");
   v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
   if(Build.VERSION.SDK_INT>=29) v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/QUICK BUTTON X");
   Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
   if(uri!=null) { OutputStream out=getContentResolver().openOutputStream(uri); if(out!=null){clean.compress(Bitmap.CompressFormat.PNG,100,out);out.close();} }
   clean.recycle();
  } catch(Exception ignored) {
  } finally {
   if(img!=null)img.close(); if(padded!=null)padded.recycle(); cleanup();
  }
 }
 private void cleanup() {
  try{if(display!=null)display.release();}catch(Exception e){}
  try{if(reader!=null)reader.close();}catch(Exception e){}
  try{if(projection!=null)projection.stop();}catch(Exception e){}
  stopForeground(true); stopSelf();
 }
 @Override public IBinder onBind(Intent i){return null;}
}
