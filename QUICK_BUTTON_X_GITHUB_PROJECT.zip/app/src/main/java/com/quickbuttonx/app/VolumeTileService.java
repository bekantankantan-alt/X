package com.quickbuttonx.app;
import android.content.Context;
import android.media.AudioManager;
public class VolumeTileService extends BaseTileService {
    @Override public void onClick() {
        super.onClick();
        try {
            AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
        } catch (Exception ignored) {}
        finishTile();
    }
}
