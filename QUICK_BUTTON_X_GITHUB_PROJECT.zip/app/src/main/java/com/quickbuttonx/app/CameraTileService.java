package com.quickbuttonx.app;
import android.content.Intent;
import android.provider.MediaStore;
public class CameraTileService extends BaseTileService {
    @Override public void onClick() {
        super.onClick();
        Intent i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        if (i.resolveActivity(getPackageManager()) == null) i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        launch(i);
    }
}
