package com.quickbuttonx.app;
import android.content.Intent;
import android.provider.MediaStore;
public class GalleryTileService extends BaseTileService {
    @Override public void onClick() {
        super.onClick();
        Intent i = new Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        i.setType("image/*");
        if (i.resolveActivity(getPackageManager()) == null) {
            i = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.photos");
        }
        if (i == null || i.resolveActivity(getPackageManager()) == null) {
            i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_APP_GALLERY);
        }
        launch(i);
    }
}
