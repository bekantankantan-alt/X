package com.quickbuttonx.app;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
public class ScreenshotAccessibilityService extends AccessibilityService {
    private static ScreenshotAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    public static boolean performScreenshot() {
        return instance != null && android.os.Build.VERSION.SDK_INT >= 28
            && instance.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
    }
}
