package com.quickbuttonx.app;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class ScreenshotAccessibilityService extends AccessibilityService {
    private static ScreenshotAccessibilityService instance;
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static final long SCREENSHOT_DELAY_MS = 1500L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // No window content is read or collected.
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean performScreenshot() {
        final ScreenshotAccessibilityService service = instance;
        if (service == null || android.os.Build.VERSION.SDK_INT < 28) {
            return false;
        }

        // Close the Quick Settings / notification shade first.
        boolean dismissed = service.performGlobalAction(GLOBAL_ACTION_BACK);
        if (!dismissed) {
            // Still wait briefly in case Android is animating the shade closed.
        }

        handler.postDelayed(() -> {
            ScreenshotAccessibilityService current = instance;
            if (current != null) {
                current.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
            }
        }, SCREENSHOT_DELAY_MS);

        return true;
    }
}
