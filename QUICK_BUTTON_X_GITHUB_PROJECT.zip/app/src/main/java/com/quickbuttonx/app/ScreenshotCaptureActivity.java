package com.quickbuttonx.app;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
public class ScreenshotCaptureActivity extends Activity {
 private static final int REQ=4107;
 @Override protected void onCreate(Bundle b) {
  super.onCreate(b);
  MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
  if(m==null){finish();return;}
  startActivityForResult(m.createScreenCaptureIntent(),REQ);
 }
 @Override protected void onActivityResult(int r,int c,Intent d) {
  super.onActivityResult(r,c,d);
  if(r==REQ && c==RESULT_OK && d!=null) {
   Intent s=new Intent(this,ScreenshotCaptureService.class);
   s.putExtra("resultCode",c); s.putExtra("resultData",d);
   if(Build.VERSION.SDK_INT>=26) startForegroundService(s); else startService(s);
  }
  finish();
 }
}
