package com.quickbuttonx.app;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,36,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(0xFF111111);
  TextView title=new TextView(this); title.setText("QUICK BUTTON X"); title.setTextSize(25); title.setTextColor(0xFFFFA000); title.setGravity(Gravity.CENTER); root.addView(title);
  TextView info=new TextView(this); info.setText("BANK SAFE EDITION — TANPA ACCESSIBILITY\n\nTambahkan tile Screenshot, Galeri, Kamera, dan Volume melalui Edit Quick Settings.\n\nSaat Screenshot ditekan, Android akan meminta izin berbagi layar. Setujui untuk mengambil screenshot. Gambar disimpan ke Pictures/QUICK BUTTON X.\n\nTidak ada layanan Accessibility atau izin membaca layar."); info.setTextColor(0xFFFFFFFF); info.setTextSize(16); info.setPadding(0,24,0,0); root.addView(info);
  setContentView(root);
 }
}
