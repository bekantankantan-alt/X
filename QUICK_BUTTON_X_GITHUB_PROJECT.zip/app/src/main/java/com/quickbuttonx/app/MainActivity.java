package com.quickbuttonx.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("QUICK BUTTON X");
        title.setTextSize(25);
        title.setTextColor(0xFFFFA000);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 12, 0, 18);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Tambahkan tombol ke panel Quick Settings agar bisa dipakai dari deretan WiFi dan Data Seluler.\n\n1. Tarik panel notifikasi dua kali.\n2. Tekan tombol Edit / ikon pensil.\n3. Cari Screenshot, Galeri, Kamera, dan Volume.\n4. Seret tombol ke panel aktif.\n\nAgar Screenshot berfungsi, aktifkan layanan aksesibilitas QUICK BUTTON X di tombol di bawah. Izin ini hanya dipakai untuk perintah screenshot.");
        info.setTextSize(16);
        info.setTextColor(0xFFFFFFFF);
        info.setLineSpacing(5, 1);
        root.addView(info);

        Button access = button("AKTIFKAN IZIN SCREENSHOT");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button panel = button("BUKA PENGATURAN QUICK SETTINGS");
        panel.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception ignored) {}
        });
        root.addView(panel);

        TextView note = new TextView(this);
        note.setText("Catatan: Galeri dan Kamera membuka aplikasi bawaan yang tersedia di HP. Tombol Volume menampilkan panel kontrol volume.");
        note.setTextColor(0xFFBBBBBB);
        note.setTextSize(13);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);
        setContentView(root);
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(0xFF111111);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFA000));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 14;
        b.setLayoutParams(lp);
        return b;
    }
}
