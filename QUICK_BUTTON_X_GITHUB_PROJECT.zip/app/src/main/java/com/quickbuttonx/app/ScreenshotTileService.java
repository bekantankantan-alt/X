package com.quickbuttonx.app;
import android.content.Intent;
public class ScreenshotTileService extends BaseTileService {
    @Override public void onClick() {
        super.onClick();
        if (ScreenshotAccessibilityService.performScreenshot()) {
            finishTile();
        } else {
            launch(new Intent(this, MainActivity.class));
        }
    }
}
