package com.quickbuttonx.app;
import android.content.Intent;
import android.service.quicksettings.TileService;
public class ScreenshotTileService extends TileService {
 @Override public void onClick() {
  super.onClick();
  Intent i=new Intent(this,ScreenshotCaptureActivity.class);
  i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
  startActivityAndCollapse(i);
 }
}
