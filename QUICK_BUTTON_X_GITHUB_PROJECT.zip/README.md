# QUICK BUTTON X — BANK SAFE EDITION V2
Android project for Realme Narzo 50i / Android 11.

- AccessibilityService has been completely removed.
- Screenshot uses Android MediaProjection and requires the system's explicit screen-sharing confirmation.
- Capture waits about 1.5 seconds and saves PNG to Pictures/QUICK BUTTON X.
- Gallery, Camera, and Volume Quick Settings tiles remain.

Note: Android will show its screen-capture consent prompt. This app cannot take silent screenshots. Removing Accessibility reduces this specific bank-warning trigger but cannot guarantee every banking app accepts sideloaded apps.
