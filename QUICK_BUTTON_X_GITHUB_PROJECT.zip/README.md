# QUICK BUTTON X

Project Android ringan untuk Realme Narzo 50i / Android 11.

## Fitur
- Quick Settings tile: Screenshot, Galeri, Kamera, Volume.
- Galeri dan kamera membuka aplikasi yang tersedia di perangkat.
- Volume memunculkan UI kontrol volume sistem.
- Screenshot memakai AccessibilityService dan perlu diaktifkan manual.

## Cara memakai
1. Install APK.
2. Buka QUICK BUTTON X.
3. Aktifkan layanan aksesibilitas QUICK BUTTON X - Screenshot.
4. Tarik panel notifikasi dua kali, tekan Edit/pensil.
5. Tambahkan tile Screenshot, Galeri, Kamera, dan Volume.

Tile Quick Settings harus ditambahkan manual oleh pengguna karena Android membatasi aplikasi untuk menyematkan tile sendiri.

## Build
GitHub Actions memakai `.github/workflows/build.yml`. Output APK tersedia sebagai artifact `QUICK_BUTTON_X_APK`.
